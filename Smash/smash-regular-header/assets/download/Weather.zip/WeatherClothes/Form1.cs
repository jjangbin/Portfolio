﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;
using System.Xml;

namespace WeatherClothes
{
    public partial class Form1 : Form
    {
        Weather w1;
        Weather w2;
        Weather w3;
        Weather w4;
        Weather w5;
        Weather w6;

        private const string MAXTMP = "최고: ";
        private const string MINTMP = "최저: ";
        private const string TMP = " ˚C";
        
        string strURL = "http://www.kma.go.kr/weather/forecast/mid-term-xml.jsp";
        string strCity = "";
        public Form1()
        {
            InitializeComponent();

            todayLabel.Text = DateTime.Now.ToString("오늘은 " + "yyyy-MM-dd" + " 입니다.");
            AreaCBox.SelectedIndex = 0;
        }

        //  지역이 변경될떄
        private void AreaCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataManager.printLog(AreaCBox.Text);
            DataManager.printLog("지역선택", DateTime.Now.ToString("yyyy-MM-dd"));

            try
            {
                using (XmlReader xr = XmlReader.Create(strURL))
                {
                    string strMsg = "";
                    XmlWriterSettings ws = new XmlWriterSettings();
                    ws.Indent = true;
                    bool bCheck = false;
                    int iCount = 0;
                    strCity = AreaCBox.Text;

                    while (xr.Read())
                    {
                        switch (xr.NodeType)
                        {
                            case XmlNodeType.CDATA:
                                txtMsg.Text = xr.Value.ToString().Replace("<br />", " ");
                                break;
                            case XmlNodeType.Text:
                                if (xr.Value.Equals(strCity))
                                {
                                    bCheck = true;
                                }
                                if (bCheck)
                                {
                                    DateTime dt;
                                    bool b = DateTime.TryParse(xr.Value.ToString(), out dt);
                                    if (b)
                                    {
                                        strMsg += "/";
                                    }
                                    strMsg += xr.Value + ",";
                                    iCount += 1;
                                    if (iCount > 36)
                                    {
                                        bCheck = false;
                                    }
                                }
                                break;
                        }
                    }

                    string[] strTmp = strMsg.Split('/');

                    string[] strWh1 = strTmp[1].Split(',');
                    w1 = new Weather(strWh1[0], int.Parse(strWh1[2]), int.Parse(strWh1[3]), strWh1[1]);
                    date_label1.Text = w1.Date;
                    label5.Text = MINTMP + w1.Rowtmp + TMP;
                    label6.Text = MAXTMP + w1.Hightmp + TMP;
                    label7.Text = w1.Nalssi;
                    int tempAvg = (w1.Rowtmp + w1.Hightmp) / 2;

                    string[] strWh2 = strTmp[2].Split(',');
                    w2 = new Weather(strWh2[0], int.Parse(strWh2[2]), int.Parse(strWh2[3]), strWh2[1]);
                    date_label2.Text = w2.Date;
                    label9.Text = MINTMP + w2.Rowtmp + TMP;
                    label10.Text = MAXTMP + w2.Hightmp + TMP;
                    label11.Text = w2.Nalssi;

                    string[] strWh3 = strTmp[3].Split(',');
                    w3 = new Weather(strWh3[0], int.Parse(strWh3[2]), int.Parse(strWh3[3]), strWh3[1]);
                    date_label3.Text = w3.Date;
                    label13.Text = MINTMP + w3.Rowtmp + TMP;
                    label14.Text = MAXTMP + w3.Hightmp + TMP;
                    label15.Text = w3.Nalssi;

                    string[] strWh4 = strTmp[4].Split(',');
                    w4 = new Weather(strWh4[0], int.Parse(strWh4[2]), int.Parse(strWh4[3]), strWh4[1]);
                    date_label4.Text = w4.Date;
                    label17.Text = MINTMP + w4.Rowtmp + TMP;
                    label18.Text = MAXTMP + w4.Hightmp + TMP;
                    label19.Text = w4.Nalssi;

                    string[] strWh5 = strTmp[5].Split(',');
                    w5 = new Weather(strWh5[0], int.Parse(strWh5[2]), int.Parse(strWh5[3]), strWh5[1]);
                    date_label5.Text = w5.Date;
                    label21.Text = MINTMP + w5.Rowtmp + TMP;
                    label22.Text = MAXTMP + w5.Hightmp + TMP;
                    label23.Text = w5.Nalssi;

                    string[] strWh6 = strTmp[6].Split(',');
                    w6 = new Weather(strWh6[0], int.Parse(strWh6[2]), int.Parse(strWh6[3]), strWh6[1]);
                    date_label6.Text = w6.Date;
                    label25.Text = MINTMP + w6.Rowtmp + TMP;
                    label26.Text = MAXTMP + w6.Hightmp + TMP;
                    label27.Text = w6.Nalssi;

                    rmdClothes(w1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
            }
        }

        private void rmdClothes(Weather wt)
        {
            double tmpAvg = (wt.Rowtmp + wt.Hightmp) / 2;
            if (tmpAvg <= 4)
            {
                recommendPic.Image = getImage("https://img.huffingtonpost.com/asset/5f98bd29290000b216c6ad01.jpeg?cache=UjE0hUwaF5&ops=scalefit_720_noupscale&format=webp");
                recommendLbl.Text = "패딩, 두꺼운 코트, 목도리, 기모제품 추천";
            }
            else if (tmpAvg > 4 && tmpAvg <= 6.5)
            {
                recommendPic.Image = getImage("http://img.newspim.com/news/2017/12/04/1712041417265150_w.jpg");
                recommendLbl.Text = "코트, 가죽자켓,히트텍, 니트, 레깅스 추천";
            }
            else if (tmpAvg > 6.5 && tmpAvg <= 10)
            {
                recommendPic.Image = getImage("http://img7.sjfzxm.com/upload/robotremote/2019/09/07/f68c04386d2c07bbb99302a745208b81.jpg");
                recommendLbl.Text = "자켓, 트렌치코트, 야상, 니트, 청바지, 스타킹 추천";
            }
            else if (tmpAvg > 10 && tmpAvg <= 15)
            {
                recommendPic.Image = getImage("http://img7.sjfzxm.com/upload/robotremote/2019/09/07/4d2f99c19907dbec8aef03f5700313f0.jpg");
                recommendLbl.Text = "자켓, 가디건, 야상, 스타킹, 청바지, 면바지 추천";
            }
            else if (tmpAvg > 15 && tmpAvg <= 18)
            {
                recommendPic.Image = getImage("https://img1.daumcdn.net/thumb/R720x0/?fname=https%3A%2F%2Ft1.daumcdn.net%2Fliveboard%2Fedit%2F317cde64f2544aeb99c768a349383e99.JPG");
                recommendLbl.Text = "얇은 니트, 맨투맨, 가디건, 청바지 추천";
            }
            else if (tmpAvg > 18 && tmpAvg <= 21)
            {
                recommendPic.Image = getImage("https://img1.daumcdn.net/thumb/R720x0/?fname=https%3A%2F%2Ft1.daumcdn.net%2Fliveboard%2Fedit%2Fc8942deb52b645139e3aad8d6e0ebdc2.JPG");
                recommendLbl.Text = "얇은 가디건, 긴팔, 면바지, 청바지 추천";
            }
            else if (tmpAvg > 21 && tmpAvg <= 27)
            {
                recommendPic.Image = getImage("https://img1.daumcdn.net/thumb/R720x0/?fname=https%3A%2F%2Ft1.daumcdn.net%2Fliveboard%2FDIMAZINE%2F911e0582181e4bf990709531da9d5200.JPG");
                recommendLbl.Text = "반팔, 얇은 셔츠, 반바지, 면바지 추천";
            }
            else if (tmpAvg >= 28)
            {
                recommendPic.Image = getImage("https://t1.daumcdn.net/cfile/blog/2452833951FA20B834");
                recommendLbl.Text = "민소매, 반팔, 반바지, 원피스 추천";
            }
            recommendPic.SizeMode = PictureBoxSizeMode.Zoom;
        }

        public static Bitmap getImage(string img)
        {
            WebClient Downloader = new WebClient();
            Stream ImageStream = Downloader.OpenRead(img);
            Bitmap DownloadImage = Bitmap.FromStream(ImageStream) as Bitmap;
            return DownloadImage;
        }

        private void date_label_Click(object sender, EventArgs e)
        {
            Label label = sender as Label;
            switch (label.Tag.ToString())
            {
                case "1":
                    rmdClothes(w1);
                    break;
                case "2":
                    rmdClothes(w2);
                    break;
                case "3":
                    rmdClothes(w3);
                    break;
                case "4":
                    rmdClothes(w4);
                    break;
                case "5":
                    rmdClothes(w5);
                    break;
                case "6":
                    rmdClothes(w6);
                    break;

            }

        }

        private void date_label1_MouseEnter(object sender, EventArgs e)
        {
            Label label = sender as Label;
            label.ForeColor = Color.LightSkyBlue;
        }

        private void date_label1_MouseLeave(object sender, EventArgs e)
        {
            Label label = sender as Label;
            label.ForeColor = Color.DodgerBlue;
        }
    }
}
