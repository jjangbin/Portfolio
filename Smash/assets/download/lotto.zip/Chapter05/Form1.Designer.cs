﻿
namespace Chapter05
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Exit_btn = new Sunny.UI.UISymbolButton();
            this.TitleName = new Sunny.UI.UISymbolLabel();
            this.NumBtn = new CxFlatUI.CxFlatRoundButton();
            this.lotto_num1 = new Sunny.UI.UISymbolButton();
            this.lotto_num2 = new Sunny.UI.UISymbolButton();
            this.lotto_num3 = new Sunny.UI.UISymbolButton();
            this.lotto_num4 = new Sunny.UI.UISymbolButton();
            this.lotto_num5 = new Sunny.UI.UISymbolButton();
            this.lotto_num6 = new Sunny.UI.UISymbolButton();
            this.plus = new System.Windows.Forms.Label();
            this.lottoBonusNum = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // Exit_btn
            // 
            this.Exit_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit_btn.FillColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.FillHoverColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Exit_btn.FillPressColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Exit_btn.FillSelectedColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.Exit_btn.IsCircle = true;
            this.Exit_btn.Location = new System.Drawing.Point(654, 1);
            this.Exit_btn.MinimumSize = new System.Drawing.Size(1, 1);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.RectColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.RectDisableColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.RectHoverColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.RectPressColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.RectSelectedColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Exit_btn.Size = new System.Drawing.Size(30, 30);
            this.Exit_btn.Style = Sunny.UI.UIStyle.Custom;
            this.Exit_btn.Symbol = 61457;
            this.Exit_btn.SymbolSize = 30;
            this.Exit_btn.TabIndex = 7;
            this.Exit_btn.Click += new System.EventHandler(this.uiSymbolButton1_Click);
            // 
            // TitleName
            // 
            this.TitleName.Font = new System.Drawing.Font("한컴 윤고딕 230", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.TitleName.Location = new System.Drawing.Point(1, 1);
            this.TitleName.MinimumSize = new System.Drawing.Size(1, 1);
            this.TitleName.Name = "TitleName";
            this.TitleName.Padding = new System.Windows.Forms.Padding(28, 0, 0, 0);
            this.TitleName.Size = new System.Drawing.Size(364, 41);
            this.TitleName.Symbol = 61922;
            this.TitleName.TabIndex = 9;
            this.TitleName.Text = "당첨 확률이 높은 로또 번호 생성기";
            // 
            // NumBtn
            // 
            this.NumBtn.ButtonType = CxFlatUI.ButtonType.Primary;
            this.NumBtn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.NumBtn.Location = new System.Drawing.Point(46, 73);
            this.NumBtn.Name = "NumBtn";
            this.NumBtn.Size = new System.Drawing.Size(80, 80);
            this.NumBtn.TabIndex = 10;
            this.NumBtn.Text = "오늘밤";
            this.NumBtn.TextColor = System.Drawing.Color.White;
            this.NumBtn.Click += new System.EventHandler(this.NumBtn_Click);
            // 
            // lotto_num1
            // 
            this.lotto_num1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.lotto_num1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num1.IsCircle = true;
            this.lotto_num1.Location = new System.Drawing.Point(151, 82);
            this.lotto_num1.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num1.Name = "lotto_num1";
            this.lotto_num1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.lotto_num1.Size = new System.Drawing.Size(60, 60);
            this.lotto_num1.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num1.Symbol = 91;
            this.lotto_num1.SymbolSize = 0;
            this.lotto_num1.TabIndex = 12;
            this.lotto_num1.Text = "주";
            // 
            // lotto_num2
            // 
            this.lotto_num2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(199)))), ((int)(((byte)(241)))));
            this.lotto_num2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num2.IsCircle = true;
            this.lotto_num2.Location = new System.Drawing.Point(217, 82);
            this.lotto_num2.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num2.Name = "lotto_num2";
            this.lotto_num2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(199)))), ((int)(((byte)(241)))));
            this.lotto_num2.Size = new System.Drawing.Size(60, 60);
            this.lotto_num2.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num2.Symbol = 91;
            this.lotto_num2.SymbolSize = 0;
            this.lotto_num2.TabIndex = 12;
            this.lotto_num2.Text = "인";
            // 
            // lotto_num3
            // 
            this.lotto_num3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(113)))), ((int)(((byte)(113)))));
            this.lotto_num3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num3.IsCircle = true;
            this.lotto_num3.Location = new System.Drawing.Point(283, 82);
            this.lotto_num3.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num3.Name = "lotto_num3";
            this.lotto_num3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(113)))), ((int)(((byte)(113)))));
            this.lotto_num3.Size = new System.Drawing.Size(60, 60);
            this.lotto_num3.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num3.Symbol = 91;
            this.lotto_num3.SymbolSize = 0;
            this.lotto_num3.TabIndex = 12;
            this.lotto_num3.Text = "공";
            // 
            // lotto_num4
            // 
            this.lotto_num4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.lotto_num4.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num4.IsCircle = true;
            this.lotto_num4.Location = new System.Drawing.Point(349, 82);
            this.lotto_num4.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num4.Name = "lotto_num4";
            this.lotto_num4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            this.lotto_num4.Size = new System.Drawing.Size(60, 60);
            this.lotto_num4.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num4.Symbol = 91;
            this.lotto_num4.SymbolSize = 0;
            this.lotto_num4.TabIndex = 12;
            this.lotto_num4.Text = "나";
            // 
            // lotto_num5
            // 
            this.lotto_num5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(217)))), ((int)(((byte)(64)))));
            this.lotto_num5.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num5.IsCircle = true;
            this.lotto_num5.Location = new System.Drawing.Point(415, 82);
            this.lotto_num5.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num5.Name = "lotto_num5";
            this.lotto_num5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(217)))), ((int)(((byte)(64)))));
            this.lotto_num5.Size = new System.Drawing.Size(60, 60);
            this.lotto_num5.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num5.Symbol = 91;
            this.lotto_num5.SymbolSize = 0;
            this.lotto_num5.TabIndex = 12;
            this.lotto_num5.Text = "야";
            // 
            // lotto_num6
            // 
            this.lotto_num6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lotto_num6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(138)))), ((int)(((byte)(238)))));
            this.lotto_num6.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lotto_num6.IsCircle = true;
            this.lotto_num6.Location = new System.Drawing.Point(481, 82);
            this.lotto_num6.MinimumSize = new System.Drawing.Size(1, 1);
            this.lotto_num6.Name = "lotto_num6";
            this.lotto_num6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(138)))), ((int)(((byte)(238)))));
            this.lotto_num6.Size = new System.Drawing.Size(60, 60);
            this.lotto_num6.Style = Sunny.UI.UIStyle.Custom;
            this.lotto_num6.Symbol = 91;
            this.lotto_num6.SymbolSize = 0;
            this.lotto_num6.TabIndex = 12;
            this.lotto_num6.Text = "나";
            // 
            // plus
            // 
            this.plus.AutoSize = true;
            this.plus.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.plus.Location = new System.Drawing.Point(547, 100);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(30, 27);
            this.plus.TabIndex = 13;
            this.plus.Text = "+";
            // 
            // lottoBonusNum
            // 
            this.lottoBonusNum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lottoBonusNum.FillColor = System.Drawing.Color.Orange;
            this.lottoBonusNum.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lottoBonusNum.IsCircle = true;
            this.lottoBonusNum.Location = new System.Drawing.Point(583, 73);
            this.lottoBonusNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.lottoBonusNum.Name = "lottoBonusNum";
            this.lottoBonusNum.RectColor = System.Drawing.Color.Orange;
            this.lottoBonusNum.Size = new System.Drawing.Size(80, 80);
            this.lottoBonusNum.Style = Sunny.UI.UIStyle.Custom;
            this.lottoBonusNum.Symbol = 91;
            this.lottoBonusNum.SymbolSize = 0;
            this.lottoBonusNum.TabIndex = 12;
            this.lottoBonusNum.Text = "보너스";
            this.lottoBonusNum.TipsColor = System.Drawing.Color.Orange;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(684, 190);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.lottoBonusNum);
            this.Controls.Add(this.lotto_num6);
            this.Controls.Add(this.lotto_num5);
            this.Controls.Add(this.lotto_num4);
            this.Controls.Add(this.lotto_num3);
            this.Controls.Add(this.lotto_num2);
            this.Controls.Add(this.lotto_num1);
            this.Controls.Add(this.NumBtn);
            this.Controls.Add(this.TitleName);
            this.Controls.Add(this.Exit_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "로또번호생성기 ver 0.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Sunny.UI.UISymbolButton Exit_btn;
        private Sunny.UI.UISymbolLabel TitleName;
        private CxFlatUI.CxFlatRoundButton NumBtn;
        private Sunny.UI.UISymbolButton lotto_num1;
        private Sunny.UI.UISymbolButton lotto_num2;
        private Sunny.UI.UISymbolButton lotto_num3;
        private Sunny.UI.UISymbolButton lotto_num4;
        private Sunny.UI.UISymbolButton lotto_num5;
        private Sunny.UI.UISymbolButton lotto_num6;
        private System.Windows.Forms.Label plus;
        private Sunny.UI.UISymbolButton lottoBonusNum;
    }
}

