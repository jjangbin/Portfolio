﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();                          
        }
        private void NumBtn_Click(object sender, EventArgs e)
        {
            Sunny.UI.UISymbolButton[] buttonList = new Sunny.UI.UISymbolButton[7];
            buttonList[0] = lotto_num1;
            buttonList[1] = lotto_num2;
            buttonList[2] = lotto_num3;
            buttonList[3] = lotto_num4;
            buttonList[4] = lotto_num5;
            buttonList[5] = lotto_num6;
            buttonList[6] = lottoBonusNum;

            NumBtn.Text = "당첨!";
            int[] a = new int[7];
            Random r = new Random();
            int sum = 0;

            //while (true)
            {
            lotto:
                while (true)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        
                        a[i] = r.Next(1, 46);
                        sum += a[i];

                        for (int j = 0; j < i; j++)
                        {
                            if (a[i] == a[j])
                            {
                                sum -= a[i];
                                i--;
                            }
                            //예외2. 첫번째 자리(1~34)/두번째자리(2~36)/세번째자리(3~39)를 벗어난 당첨번호는 없었다.
                            if (a[0] > 34)
                            {
                                Console.WriteLine("sum2" + sum + "a[0]" + a[0]);
                                i = -1;
                                sum = 0;
                                break;
                            }
                            if (i == 1 && (a[1] < 2) || (a[1] > 36))
                            {
                                Console.WriteLine("sum2" + sum + "a[1]" + a[1]);
                                i = 0;
                                sum = 0;
                                break;
                            }
                            if (i == 2 && (a[2] < 3) || (a[2] > 39))
                            {
                                Console.WriteLine("sum2" + sum + "a[2]" + a[2]);
                                i = 1;
                                sum = 0;
                                break;
                            }
                            if (i == 3 && (a[3] < 4))
                            {
                                Console.WriteLine("sum2" + sum + "a[3]" + a[3]);
                                i = 2;
                                sum = 0;
                                break;
                            }
                            if (i == 4 && (a[4] < 5))
                            {
                                Console.WriteLine("sum2" + sum + "a[4]" + a[4]);
                                i = 3;
                                sum = 0;
                                break;
                            }
                            if (i == 5 && (a[5] < 6))
                            {
                                Console.WriteLine("sum2" + sum + "a[5]" + a[5]);
                                i = 4;
                                sum = 0;
                                break;
                            }
                            
                        }
                    }
                    //예외1.지금까지 합계가 48보다 작거나, 238보다 큰 당첨번호는 한번도 없었다.
                    //합계 100~200사이가 전체의 80%로 10번 추천시 8번이나 이 구간에서 당첨번호 조합이 출현하고 있다.
                    if (sum < 100 || sum > 200)
                    {
                        Console.WriteLine("sum:(sum < 100 || sum > 200)" + sum);
                        sum = 0;
                        continue;
                    }
                    else
                        break; 
                }
                Console.WriteLine("sum:" + sum);

                //숫자 정렬
                /*Array.Sort(a);*/
                int temp = 0;
                for (int i = 0; i < 6; i++)
                {
                    for (int j = i+1 ; j < 5; j++)
                    {
                        if(a[i] > a[j])
                        {
                            temp = a[i];
                            a[i] = a[j];
                            a[j] = temp;
                        }
                    }
                    
                }

                //조건3. 고저차가 41-44일 경우가 확률이 가장 높다
                if ((a[5] - a[0]) < 41 || (a[5] - a[0]) > 44)
                {
                    sum = 0;
                    goto lotto;
                }

                for (int k = 0; k < 7; k++)
                {                    
                    buttonList[k].Text = (a[k].ToString());
                    buttonList[k].Refresh();
                }
                //sum = 0;
                //Thread.Sleep(1000);
            }

        }

        private void uiSymbolButton1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
