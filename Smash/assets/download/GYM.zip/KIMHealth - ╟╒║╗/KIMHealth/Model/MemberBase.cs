﻿namespace KIMHealth.Model
{
    internal class MemberBase
    {
    }
}