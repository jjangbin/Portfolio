﻿
namespace KIMHealth.Ui
{
    partial class LockerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LockerForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.WhatTime = new System.Windows.Forms.TextBox();
            this.lock_1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lock_2 = new System.Windows.Forms.Label();
            this.lock_3 = new System.Windows.Forms.Label();
            this.lock_4 = new System.Windows.Forms.Label();
            this.lock_5 = new System.Windows.Forms.Label();
            this.lock_10 = new System.Windows.Forms.Label();
            this.lock_9 = new System.Windows.Forms.Label();
            this.lock_8 = new System.Windows.Forms.Label();
            this.lock_7 = new System.Windows.Forms.Label();
            this.lock_6 = new System.Windows.Forms.Label();
            this.lock_15 = new System.Windows.Forms.Label();
            this.lock_14 = new System.Windows.Forms.Label();
            this.lock_13 = new System.Windows.Forms.Label();
            this.lock_12 = new System.Windows.Forms.Label();
            this.lock_11 = new System.Windows.Forms.Label();
            this.lock_20 = new System.Windows.Forms.Label();
            this.lock_19 = new System.Windows.Forms.Label();
            this.lock_18 = new System.Windows.Forms.Label();
            this.lock_17 = new System.Windows.Forms.Label();
            this.lock_16 = new System.Windows.Forms.Label();
            this.lock_30 = new System.Windows.Forms.Label();
            this.lock_29 = new System.Windows.Forms.Label();
            this.lock_28 = new System.Windows.Forms.Label();
            this.lock_27 = new System.Windows.Forms.Label();
            this.lock_26 = new System.Windows.Forms.Label();
            this.lock_25 = new System.Windows.Forms.Label();
            this.lock_24 = new System.Windows.Forms.Label();
            this.lock_23 = new System.Windows.Forms.Label();
            this.lock_22 = new System.Windows.Forms.Label();
            this.lock_21 = new System.Windows.Forms.Label();
            this.lock_40 = new System.Windows.Forms.Label();
            this.lock_39 = new System.Windows.Forms.Label();
            this.lock_38 = new System.Windows.Forms.Label();
            this.lock_37 = new System.Windows.Forms.Label();
            this.lock_36 = new System.Windows.Forms.Label();
            this.lock_35 = new System.Windows.Forms.Label();
            this.lock_34 = new System.Windows.Forms.Label();
            this.lock_33 = new System.Windows.Forms.Label();
            this.lock_32 = new System.Windows.Forms.Label();
            this.lock_31 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_lent = new System.Windows.Forms.Button();
            this.button_return = new System.Windows.Forms.Button();
            this.textBox_lockerNum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // WhatTime
            // 
            this.WhatTime.Location = new System.Drawing.Point(45, 506);
            this.WhatTime.Name = "WhatTime";
            this.WhatTime.Size = new System.Drawing.Size(100, 21);
            this.WhatTime.TabIndex = 0;
            // 
            // lock_1
            // 
            this.lock_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_1.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_1.Location = new System.Drawing.Point(42, 44);
            this.lock_1.Name = "lock_1";
            this.lock_1.Size = new System.Drawing.Size(50, 70);
            this.lock_1.TabIndex = 1;
            this.lock_1.Text = "1";
            this.lock_1.Click += new System.EventHandler(this.Locker_Click);
            this.lock_1.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_1.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_1.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 505);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(821, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lock_2
            // 
            this.lock_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_2.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_2.Location = new System.Drawing.Point(111, 44);
            this.lock_2.Name = "lock_2";
            this.lock_2.Size = new System.Drawing.Size(50, 70);
            this.lock_2.TabIndex = 2;
            this.lock_2.Text = "2";
            this.lock_2.Click += new System.EventHandler(this.Locker_Click);
            this.lock_2.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_2.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_2.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_3
            // 
            this.lock_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_3.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_3.Location = new System.Drawing.Point(180, 44);
            this.lock_3.Name = "lock_3";
            this.lock_3.Size = new System.Drawing.Size(50, 70);
            this.lock_3.TabIndex = 3;
            this.lock_3.Text = "3";
            this.lock_3.Click += new System.EventHandler(this.Locker_Click);
            this.lock_3.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_3.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_3.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_4
            // 
            this.lock_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_4.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_4.Location = new System.Drawing.Point(249, 44);
            this.lock_4.Name = "lock_4";
            this.lock_4.Size = new System.Drawing.Size(50, 70);
            this.lock_4.TabIndex = 4;
            this.lock_4.Text = "4";
            this.lock_4.Click += new System.EventHandler(this.Locker_Click);
            this.lock_4.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_4.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_4.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_5
            // 
            this.lock_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_5.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_5.Location = new System.Drawing.Point(318, 44);
            this.lock_5.Name = "lock_5";
            this.lock_5.Size = new System.Drawing.Size(50, 70);
            this.lock_5.TabIndex = 5;
            this.lock_5.Text = "5";
            this.lock_5.Click += new System.EventHandler(this.Locker_Click);
            this.lock_5.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_5.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_5.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_10
            // 
            this.lock_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_10.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_10.Location = new System.Drawing.Point(663, 44);
            this.lock_10.Name = "lock_10";
            this.lock_10.Size = new System.Drawing.Size(50, 70);
            this.lock_10.TabIndex = 10;
            this.lock_10.Text = "10";
            this.lock_10.Click += new System.EventHandler(this.Locker_Click);
            this.lock_10.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_10.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_10.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_9
            // 
            this.lock_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_9.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_9.Location = new System.Drawing.Point(594, 44);
            this.lock_9.Name = "lock_9";
            this.lock_9.Size = new System.Drawing.Size(50, 70);
            this.lock_9.TabIndex = 9;
            this.lock_9.Text = "9";
            this.lock_9.Click += new System.EventHandler(this.Locker_Click);
            this.lock_9.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_9.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_9.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_8
            // 
            this.lock_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_8.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_8.Location = new System.Drawing.Point(525, 44);
            this.lock_8.Name = "lock_8";
            this.lock_8.Size = new System.Drawing.Size(50, 70);
            this.lock_8.TabIndex = 8;
            this.lock_8.Text = "8";
            this.lock_8.Click += new System.EventHandler(this.Locker_Click);
            this.lock_8.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_8.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_8.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_7
            // 
            this.lock_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_7.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_7.Location = new System.Drawing.Point(456, 44);
            this.lock_7.Name = "lock_7";
            this.lock_7.Size = new System.Drawing.Size(50, 70);
            this.lock_7.TabIndex = 7;
            this.lock_7.Text = "7";
            this.lock_7.Click += new System.EventHandler(this.Locker_Click);
            this.lock_7.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_7.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_7.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_6
            // 
            this.lock_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_6.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_6.Location = new System.Drawing.Point(387, 44);
            this.lock_6.Name = "lock_6";
            this.lock_6.Size = new System.Drawing.Size(50, 70);
            this.lock_6.TabIndex = 6;
            this.lock_6.Text = "6";
            this.lock_6.Click += new System.EventHandler(this.Locker_Click);
            this.lock_6.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_6.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_6.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_15
            // 
            this.lock_15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_15.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_15.Location = new System.Drawing.Point(318, 136);
            this.lock_15.Name = "lock_15";
            this.lock_15.Size = new System.Drawing.Size(50, 70);
            this.lock_15.TabIndex = 15;
            this.lock_15.Text = "15";
            this.lock_15.Click += new System.EventHandler(this.Locker_Click);
            this.lock_15.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_15.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_15.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_14
            // 
            this.lock_14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_14.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_14.Location = new System.Drawing.Point(249, 136);
            this.lock_14.Name = "lock_14";
            this.lock_14.Size = new System.Drawing.Size(50, 70);
            this.lock_14.TabIndex = 14;
            this.lock_14.Text = "14";
            this.lock_14.Click += new System.EventHandler(this.Locker_Click);
            this.lock_14.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_14.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_14.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_13
            // 
            this.lock_13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_13.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_13.Location = new System.Drawing.Point(180, 136);
            this.lock_13.Name = "lock_13";
            this.lock_13.Size = new System.Drawing.Size(50, 70);
            this.lock_13.TabIndex = 13;
            this.lock_13.Text = "13";
            this.lock_13.Click += new System.EventHandler(this.Locker_Click);
            this.lock_13.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_13.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_13.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_12
            // 
            this.lock_12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_12.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_12.Location = new System.Drawing.Point(111, 136);
            this.lock_12.Name = "lock_12";
            this.lock_12.Size = new System.Drawing.Size(50, 70);
            this.lock_12.TabIndex = 12;
            this.lock_12.Text = "12";
            this.lock_12.Click += new System.EventHandler(this.Locker_Click);
            this.lock_12.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_12.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_12.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_11
            // 
            this.lock_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_11.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_11.Location = new System.Drawing.Point(42, 136);
            this.lock_11.Name = "lock_11";
            this.lock_11.Size = new System.Drawing.Size(50, 70);
            this.lock_11.TabIndex = 11;
            this.lock_11.Text = "11";
            this.lock_11.Click += new System.EventHandler(this.Locker_Click);
            this.lock_11.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_11.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_11.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_20
            // 
            this.lock_20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_20.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_20.Location = new System.Drawing.Point(663, 136);
            this.lock_20.Name = "lock_20";
            this.lock_20.Size = new System.Drawing.Size(50, 70);
            this.lock_20.TabIndex = 20;
            this.lock_20.Text = "20";
            this.lock_20.Click += new System.EventHandler(this.Locker_Click);
            this.lock_20.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_20.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_20.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_19
            // 
            this.lock_19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_19.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_19.Location = new System.Drawing.Point(594, 136);
            this.lock_19.Name = "lock_19";
            this.lock_19.Size = new System.Drawing.Size(50, 70);
            this.lock_19.TabIndex = 19;
            this.lock_19.Text = "19";
            this.lock_19.Click += new System.EventHandler(this.Locker_Click);
            this.lock_19.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_19.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_19.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_18
            // 
            this.lock_18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_18.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_18.Location = new System.Drawing.Point(525, 136);
            this.lock_18.Name = "lock_18";
            this.lock_18.Size = new System.Drawing.Size(50, 70);
            this.lock_18.TabIndex = 18;
            this.lock_18.Text = "18";
            this.lock_18.Click += new System.EventHandler(this.Locker_Click);
            this.lock_18.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_18.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_18.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_17
            // 
            this.lock_17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_17.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_17.Location = new System.Drawing.Point(456, 136);
            this.lock_17.Name = "lock_17";
            this.lock_17.Size = new System.Drawing.Size(50, 70);
            this.lock_17.TabIndex = 17;
            this.lock_17.Text = "17";
            this.lock_17.Click += new System.EventHandler(this.Locker_Click);
            this.lock_17.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_17.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_17.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_16
            // 
            this.lock_16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_16.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_16.Location = new System.Drawing.Point(387, 136);
            this.lock_16.Name = "lock_16";
            this.lock_16.Size = new System.Drawing.Size(50, 70);
            this.lock_16.TabIndex = 16;
            this.lock_16.Text = "16";
            this.lock_16.Click += new System.EventHandler(this.Locker_Click);
            this.lock_16.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_16.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_16.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_30
            // 
            this.lock_30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_30.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_30.Location = new System.Drawing.Point(663, 230);
            this.lock_30.Name = "lock_30";
            this.lock_30.Size = new System.Drawing.Size(50, 70);
            this.lock_30.TabIndex = 30;
            this.lock_30.Text = "30";
            this.lock_30.Click += new System.EventHandler(this.Locker_Click);
            this.lock_30.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_30.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_30.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_29
            // 
            this.lock_29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_29.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_29.Location = new System.Drawing.Point(594, 230);
            this.lock_29.Name = "lock_29";
            this.lock_29.Size = new System.Drawing.Size(50, 70);
            this.lock_29.TabIndex = 29;
            this.lock_29.Text = "29";
            this.lock_29.Click += new System.EventHandler(this.Locker_Click);
            this.lock_29.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_29.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_29.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_28
            // 
            this.lock_28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_28.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_28.Location = new System.Drawing.Point(525, 230);
            this.lock_28.Name = "lock_28";
            this.lock_28.Size = new System.Drawing.Size(50, 70);
            this.lock_28.TabIndex = 28;
            this.lock_28.Text = "28";
            this.lock_28.Click += new System.EventHandler(this.Locker_Click);
            this.lock_28.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_28.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_28.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_27
            // 
            this.lock_27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_27.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_27.Location = new System.Drawing.Point(456, 230);
            this.lock_27.Name = "lock_27";
            this.lock_27.Size = new System.Drawing.Size(50, 70);
            this.lock_27.TabIndex = 27;
            this.lock_27.Text = "27";
            this.lock_27.Click += new System.EventHandler(this.Locker_Click);
            this.lock_27.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_27.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_27.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_26
            // 
            this.lock_26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_26.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_26.Location = new System.Drawing.Point(387, 230);
            this.lock_26.Name = "lock_26";
            this.lock_26.Size = new System.Drawing.Size(50, 70);
            this.lock_26.TabIndex = 26;
            this.lock_26.Text = "26";
            this.lock_26.Click += new System.EventHandler(this.Locker_Click);
            this.lock_26.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_26.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_26.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_25
            // 
            this.lock_25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_25.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_25.Location = new System.Drawing.Point(318, 230);
            this.lock_25.Name = "lock_25";
            this.lock_25.Size = new System.Drawing.Size(50, 70);
            this.lock_25.TabIndex = 25;
            this.lock_25.Text = "25";
            this.lock_25.Click += new System.EventHandler(this.Locker_Click);
            this.lock_25.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_25.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_25.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_24
            // 
            this.lock_24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_24.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_24.Location = new System.Drawing.Point(249, 230);
            this.lock_24.Name = "lock_24";
            this.lock_24.Size = new System.Drawing.Size(50, 70);
            this.lock_24.TabIndex = 24;
            this.lock_24.Text = "24";
            this.lock_24.Click += new System.EventHandler(this.Locker_Click);
            this.lock_24.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_24.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_24.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_23
            // 
            this.lock_23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_23.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_23.Location = new System.Drawing.Point(180, 230);
            this.lock_23.Name = "lock_23";
            this.lock_23.Size = new System.Drawing.Size(50, 70);
            this.lock_23.TabIndex = 23;
            this.lock_23.Text = "23";
            this.lock_23.Click += new System.EventHandler(this.Locker_Click);
            this.lock_23.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_23.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_23.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_22
            // 
            this.lock_22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_22.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_22.Location = new System.Drawing.Point(111, 230);
            this.lock_22.Name = "lock_22";
            this.lock_22.Size = new System.Drawing.Size(50, 70);
            this.lock_22.TabIndex = 22;
            this.lock_22.Text = "22";
            this.lock_22.Click += new System.EventHandler(this.Locker_Click);
            this.lock_22.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_22.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_22.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_21
            // 
            this.lock_21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_21.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_21.Location = new System.Drawing.Point(42, 230);
            this.lock_21.Name = "lock_21";
            this.lock_21.Size = new System.Drawing.Size(50, 70);
            this.lock_21.TabIndex = 21;
            this.lock_21.Text = "21";
            this.lock_21.Click += new System.EventHandler(this.Locker_Click);
            this.lock_21.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_21.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_21.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_40
            // 
            this.lock_40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_40.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_40.Location = new System.Drawing.Point(663, 320);
            this.lock_40.Name = "lock_40";
            this.lock_40.Size = new System.Drawing.Size(50, 70);
            this.lock_40.TabIndex = 40;
            this.lock_40.Text = "40";
            this.lock_40.Click += new System.EventHandler(this.Locker_Click);
            this.lock_40.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_40.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_40.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_39
            // 
            this.lock_39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_39.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_39.Location = new System.Drawing.Point(594, 320);
            this.lock_39.Name = "lock_39";
            this.lock_39.Size = new System.Drawing.Size(50, 70);
            this.lock_39.TabIndex = 39;
            this.lock_39.Text = "39";
            this.lock_39.Click += new System.EventHandler(this.Locker_Click);
            this.lock_39.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_39.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_39.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_38
            // 
            this.lock_38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_38.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_38.Location = new System.Drawing.Point(525, 320);
            this.lock_38.Name = "lock_38";
            this.lock_38.Size = new System.Drawing.Size(50, 70);
            this.lock_38.TabIndex = 38;
            this.lock_38.Text = "38";
            this.lock_38.Click += new System.EventHandler(this.Locker_Click);
            this.lock_38.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_38.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_38.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_37
            // 
            this.lock_37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_37.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_37.Location = new System.Drawing.Point(456, 320);
            this.lock_37.Name = "lock_37";
            this.lock_37.Size = new System.Drawing.Size(50, 70);
            this.lock_37.TabIndex = 37;
            this.lock_37.Text = "37";
            this.lock_37.Click += new System.EventHandler(this.Locker_Click);
            this.lock_37.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_37.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_37.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_36
            // 
            this.lock_36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_36.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_36.Location = new System.Drawing.Point(387, 320);
            this.lock_36.Name = "lock_36";
            this.lock_36.Size = new System.Drawing.Size(50, 70);
            this.lock_36.TabIndex = 36;
            this.lock_36.Text = "36";
            this.lock_36.Click += new System.EventHandler(this.Locker_Click);
            this.lock_36.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_36.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_36.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_35
            // 
            this.lock_35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_35.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_35.Location = new System.Drawing.Point(318, 320);
            this.lock_35.Name = "lock_35";
            this.lock_35.Size = new System.Drawing.Size(50, 70);
            this.lock_35.TabIndex = 35;
            this.lock_35.Text = "35";
            this.lock_35.Click += new System.EventHandler(this.Locker_Click);
            this.lock_35.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_35.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_35.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_34
            // 
            this.lock_34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_34.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_34.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lock_34.Location = new System.Drawing.Point(249, 320);
            this.lock_34.Name = "lock_34";
            this.lock_34.Size = new System.Drawing.Size(50, 70);
            this.lock_34.TabIndex = 34;
            this.lock_34.Text = "34";
            this.lock_34.Click += new System.EventHandler(this.Locker_Click);
            this.lock_34.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_34.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_34.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_33
            // 
            this.lock_33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_33.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_33.Location = new System.Drawing.Point(180, 320);
            this.lock_33.Name = "lock_33";
            this.lock_33.Size = new System.Drawing.Size(50, 70);
            this.lock_33.TabIndex = 33;
            this.lock_33.Text = "33";
            this.lock_33.Click += new System.EventHandler(this.Locker_Click);
            this.lock_33.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_33.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_33.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_32
            // 
            this.lock_32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_32.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_32.Location = new System.Drawing.Point(111, 320);
            this.lock_32.Name = "lock_32";
            this.lock_32.Size = new System.Drawing.Size(50, 70);
            this.lock_32.TabIndex = 32;
            this.lock_32.Text = "32";
            this.lock_32.Click += new System.EventHandler(this.Locker_Click);
            this.lock_32.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_32.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_32.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // lock_31
            // 
            this.lock_31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_31.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_31.Location = new System.Drawing.Point(42, 320);
            this.lock_31.Name = "lock_31";
            this.lock_31.Size = new System.Drawing.Size(50, 70);
            this.lock_31.TabIndex = 31;
            this.lock_31.Text = "31";
            this.lock_31.Click += new System.EventHandler(this.Locker_Click);
            this.lock_31.DoubleClick += new System.EventHandler(this.Locker_DoubleClick);
            this.lock_31.MouseEnter += new System.EventHandler(this.Locker_mouseEnter);
            this.lock_31.MouseLeave += new System.EventHandler(this.Locker_mouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(773, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(720, 9);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 43;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // textBox_id
            // 
            this.textBox_id.Location = new System.Drawing.Point(328, 441);
            this.textBox_id.Name = "textBox_id";
            this.textBox_id.Size = new System.Drawing.Size(100, 21);
            this.textBox_id.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(265, 445);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 45;
            this.label1.Text = "회원 번호:";
            // 
            // button_lent
            // 
            this.button_lent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_lent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_lent.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_lent.Location = new System.Drawing.Point(490, 435);
            this.button_lent.Name = "button_lent";
            this.button_lent.Size = new System.Drawing.Size(67, 33);
            this.button_lent.TabIndex = 46;
            this.button_lent.Text = "대여";
            this.button_lent.UseVisualStyleBackColor = false;
            this.button_lent.Click += new System.EventHandler(this.button_lent_Click);
            // 
            // button_return
            // 
            this.button_return.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_return.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_return.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_return.Location = new System.Drawing.Point(580, 435);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(67, 33);
            this.button_return.TabIndex = 47;
            this.button_return.Text = "반납";
            this.button_return.UseVisualStyleBackColor = false;
            this.button_return.Click += new System.EventHandler(this.button_return_Click_1);
            // 
            // textBox_lockerNum
            // 
            this.textBox_lockerNum.Location = new System.Drawing.Point(129, 441);
            this.textBox_lockerNum.Name = "textBox_lockerNum";
            this.textBox_lockerNum.Size = new System.Drawing.Size(100, 21);
            this.textBox_lockerNum.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Location = new System.Drawing.Point(62, 445);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 45;
            this.label2.Text = "락커 번호 :";
            // 
            // LockerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(821, 527);
            this.Controls.Add(this.button_return);
            this.Controls.Add(this.button_lent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_lockerNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_id);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lock_40);
            this.Controls.Add(this.lock_39);
            this.Controls.Add(this.lock_38);
            this.Controls.Add(this.lock_37);
            this.Controls.Add(this.lock_36);
            this.Controls.Add(this.lock_35);
            this.Controls.Add(this.lock_34);
            this.Controls.Add(this.lock_33);
            this.Controls.Add(this.lock_32);
            this.Controls.Add(this.lock_31);
            this.Controls.Add(this.lock_30);
            this.Controls.Add(this.lock_29);
            this.Controls.Add(this.lock_28);
            this.Controls.Add(this.lock_27);
            this.Controls.Add(this.lock_26);
            this.Controls.Add(this.lock_25);
            this.Controls.Add(this.lock_24);
            this.Controls.Add(this.lock_23);
            this.Controls.Add(this.lock_22);
            this.Controls.Add(this.lock_21);
            this.Controls.Add(this.lock_20);
            this.Controls.Add(this.lock_19);
            this.Controls.Add(this.lock_18);
            this.Controls.Add(this.lock_17);
            this.Controls.Add(this.lock_16);
            this.Controls.Add(this.lock_15);
            this.Controls.Add(this.lock_14);
            this.Controls.Add(this.lock_13);
            this.Controls.Add(this.lock_12);
            this.Controls.Add(this.lock_11);
            this.Controls.Add(this.lock_10);
            this.Controls.Add(this.lock_9);
            this.Controls.Add(this.lock_8);
            this.Controls.Add(this.lock_7);
            this.Controls.Add(this.lock_6);
            this.Controls.Add(this.lock_5);
            this.Controls.Add(this.lock_4);
            this.Controls.Add(this.lock_3);
            this.Controls.Add(this.lock_2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.lock_1);
            this.Controls.Add(this.WhatTime);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LockerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Locker";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox WhatTime;
        private System.Windows.Forms.Label lock_1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label lock_2;
        private System.Windows.Forms.Label lock_3;
        private System.Windows.Forms.Label lock_4;
        private System.Windows.Forms.Label lock_5;
        private System.Windows.Forms.Label lock_10;
        private System.Windows.Forms.Label lock_9;
        private System.Windows.Forms.Label lock_8;
        private System.Windows.Forms.Label lock_7;
        private System.Windows.Forms.Label lock_6;
        private System.Windows.Forms.Label lock_15;
        private System.Windows.Forms.Label lock_14;
        private System.Windows.Forms.Label lock_13;
        private System.Windows.Forms.Label lock_12;
        private System.Windows.Forms.Label lock_11;
        private System.Windows.Forms.Label lock_20;
        private System.Windows.Forms.Label lock_19;
        private System.Windows.Forms.Label lock_18;
        private System.Windows.Forms.Label lock_17;
        private System.Windows.Forms.Label lock_16;
        private System.Windows.Forms.Label lock_30;
        private System.Windows.Forms.Label lock_29;
        private System.Windows.Forms.Label lock_28;
        private System.Windows.Forms.Label lock_27;
        private System.Windows.Forms.Label lock_26;
        private System.Windows.Forms.Label lock_25;
        private System.Windows.Forms.Label lock_24;
        private System.Windows.Forms.Label lock_23;
        private System.Windows.Forms.Label lock_22;
        private System.Windows.Forms.Label lock_21;
        private System.Windows.Forms.Label lock_40;
        private System.Windows.Forms.Label lock_39;
        private System.Windows.Forms.Label lock_38;
        private System.Windows.Forms.Label lock_37;
        private System.Windows.Forms.Label lock_36;
        private System.Windows.Forms.Label lock_35;
        private System.Windows.Forms.Label lock_34;
        private System.Windows.Forms.Label lock_33;
        private System.Windows.Forms.Label lock_32;
        private System.Windows.Forms.Label lock_31;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_lent;
        private System.Windows.Forms.Button button_return;
        private System.Windows.Forms.TextBox textBox_lockerNum;
        private System.Windows.Forms.Label label2;
    }
}