package serial0217;

import java.util.Scanner;
import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class SerialMain2 {
	public static final String ADMIN_ID = "admin";
	public static final String GUEST_ID = "guest";
	public static final String ADMIN_PW = "1234";
	public static final String GUEST_PW = "1111";

	public static final String ADMIN_MODE = "admin_mode";
	public static final String GUEST_MODE = "guest_mode";
	public static final String OTHER_MODE = "other_mode";

	static final int MENU_TV_ON = 1;
	static final int MENU_TV_OFF = 2;
	static final int MENU_HEATER_ON = 3;
	static final int MENU_WASH_ON = 4;
	static final int MENU_EMARGENCY = 5;
	static final int MENU_ADMIN_RECONN = 6;
	static final int MENU_PROGRAM_EXIT = 7;
	static final int MENU_LOGOUT = 0;

	static final int CMD_TV_ON = '1';
	static final int CMD_TV_OFF = '2';
	static final int CMD_HEATER_ON = '3';
	static final int CMD_WASH_ON = '4';

	// ��Ʈ
	public static SerialPort initSerial() {
		//�ø��������� �����´�
		String[] portNames = SerialPortList.getPortNames();
		for (int i = 0; i < portNames.length; i++) {
			System.out.println(portNames[i]);
		}
		SerialPort serialPort = new SerialPort(portNames[0]);
		
		return serialPort;
	}
	
	public static void openSerial(SerialPort serial) {
		try {
			serial.openPort();
			serial.setParams(SerialPort.BAUDRATE_9600, 
					SerialPort.DATABITS_8, 
					SerialPort.STOPBITS_1,
					SerialPort.PARITY_NONE);
		} catch (SerialPortException e) {
			e.printStackTrace();
		}
	}


	// �α��� �޼���
	public static String Login(Scanner s) {
		System.out.println("================");
		System.out.println("����ƮȨ ���� �α���");
		System.out.println("================");
		System.out.print("ID : ");
		String id = s.next();
		System.out.print("PW : ");
		String passwd = s.next();
		String mode;

		if (id.equals(ADMIN_ID) && passwd.equals(ADMIN_PW)) {
			mode = ADMIN_MODE;
		} else if (id.equals(GUEST_ID) && passwd.equals(GUEST_PW)) {
			mode = GUEST_MODE;
		} else {
			mode = OTHER_MODE;
		}
		return mode;
	}

	// �����ڸ�� ���� �޼���
	public static int adminMenu(Scanner s) {
		System.out.println("===============");
		System.out.println("����ƮȨ ���� ������");
		System.out.println("===============");
		System.out.println("1.TV �ѱ�");
		System.out.println("2.TV ����");
		System.out.println("3.���Ϸ� ����");
		System.out.println("4.��Ź�� ����");
		System.out.println("5.��� ����");
		System.out.println("6.��� �翬��");
		System.out.println("7.����");
		System.out.println("0.�α׾ƿ�");
		System.out.println("==============");
		System.out.print("�޴�����: ");
		return s.nextInt();
	}

	// ����ڸ�� ���� �޼���
	public static int guestMenu(Scanner s) {
		System.out.println("===============");
		System.out.println("����ƮȨ ���� �����");
		System.out.println("===============");
		System.out.println("1.TV �ѱ�");
		System.out.println("2.TV ����");
		System.out.println("3.���Ϸ� ����");
		System.out.println("4.��Ź�� ����");
		System.out.println("6.����翬��");
		System.out.println("7.����");
		System.out.println("0.�α׾ƿ�");
		System.out.println("===============");
		System.out.print("�޴�����: ");
		return s.nextInt();
	}

	// ������ Ŀ�ǵ�
	public static boolean adminWork(Scanner s, SerialPort serial) {
		while (true) {
			switch (adminMenu(s)) {
			case MENU_TV_ON:
				try {
					serial.writeInt(CMD_TV_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("TV �ѱ�");
				break;
			case MENU_TV_OFF:
				try {
					serial.writeInt(CMD_TV_OFF);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("TV ����");
				break;
			case MENU_HEATER_ON:
				try {
					serial.writeInt(CMD_HEATER_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("���Ϸ� ����");
				break;
			case MENU_WASH_ON:
				try {
					serial.writeInt(CMD_WASH_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("��Ź�� ����");
				break;
			case MENU_EMARGENCY:
				System.out.println("��� ����");
				try {
//					System.out.println("1. serial: "+ serial);
					serial.closePort();
//					System.out.println("2. serial: "+ serial);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				break;
			case MENU_ADMIN_RECONN:
				break;
			case MENU_PROGRAM_EXIT:
				System.out.println("���α׷� ����");
				s.close();
				System.exit(0);
			case MENU_LOGOUT:
				System.out.println("�α׾ƿ�");
				return false;
			}
			return true;
		}
	}

	// ����� Ŀ�ǵ�
	public static boolean guestWork(Scanner s, SerialPort serial) {
		while (true) {
			switch (guestMenu(s)) {
			case MENU_TV_ON:
				try {
					serial.writeInt(CMD_TV_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("TV �ѱ�");
				break;
			case MENU_TV_OFF:
				try {
					serial.writeInt(CMD_TV_OFF);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("TV ����");
				break;
			case MENU_HEATER_ON:
				try {
					serial.writeInt(CMD_HEATER_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("���Ϸ� ����");
				break;
			case MENU_WASH_ON:
				try {
					serial.writeInt(CMD_WASH_ON);
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
				System.out.println("��Ź�� ����");
				break;
			case MENU_ADMIN_RECONN:
				break;
			case MENU_PROGRAM_EXIT:
				System.out.println("���α׷� ����");
				s.close();
				System.exit(0);
			case MENU_LOGOUT:
				System.out.println("�α׾ƿ�");
				return false;
			}
			return true;
		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		SerialPort serial = initSerial();
		openSerial(serial);
		

		while (true) {
			String mode = Login(s);
			if (mode.equals(ADMIN_MODE)) {
				while (true) {
					if (adminWork(s, serial) == false) {
						// if (!adminWork(s, serial)) �����ǹ�
						break;
					}
				}
			} else if (mode.equals(GUEST_MODE)) {
				while (true) {
					if (!guestWork(s, serial)) {
						break;
					}
				}
			} else {
				System.out.println("ID �Ǵ� PW�� �ٽ��Է��ϼ���");
			}
		}
	}
}
