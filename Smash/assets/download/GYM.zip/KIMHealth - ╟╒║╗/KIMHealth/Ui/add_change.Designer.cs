﻿
namespace KIMHealth
{
    partial class add_change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add_change));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_pt = new System.Windows.Forms.TextBox();
            this.combo_trainer = new System.Windows.Forms.ComboBox();
            this.input_btn = new System.Windows.Forms.Button();
            this.textBox_end = new System.Windows.Forms.TextBox();
            this.textBox_start = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button_okay1 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_membership = new System.Windows.Forms.TextBox();
            this.textBox_lent = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_bmi = new System.Windows.Forms.TextBox();
            this.textBox_weight = new System.Windows.Forms.TextBox();
            this.textBox_height = new System.Windows.Forms.TextBox();
            this.textBox_gender = new System.Windows.Forms.TextBox();
            this.textBox_age = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_addr = new System.Windows.Forms.TextBox();
            this.textBox_phone = new System.Windows.Forms.TextBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.checkedListBox_membership = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_pt = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_lent = new System.Windows.Forms.CheckedListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pay_price = new System.Windows.Forms.Label();
            this.pay_name = new System.Windows.Forms.Label();
            this.text_trainer = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "이름";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "휴대폰번호";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "주소";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.text_trainer);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox_pt);
            this.groupBox1.Controls.Add(this.combo_trainer);
            this.groupBox1.Controls.Add(this.input_btn);
            this.groupBox1.Controls.Add(this.textBox_end);
            this.groupBox1.Controls.Add(this.textBox_start);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.button_okay1);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox_membership);
            this.groupBox1.Controls.Add(this.textBox_lent);
            this.groupBox1.Location = new System.Drawing.Point(348, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(433, 147);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " 등록정보";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 12);
            this.label7.TabIndex = 32;
            this.label7.Text = "트레이너(선택)";
            // 
            // textBox_pt
            // 
            this.textBox_pt.Location = new System.Drawing.Point(100, 79);
            this.textBox_pt.Name = "textBox_pt";
            this.textBox_pt.Size = new System.Drawing.Size(92, 21);
            this.textBox_pt.TabIndex = 31;
            // 
            // combo_trainer
            // 
            this.combo_trainer.FormattingEnabled = true;
            this.combo_trainer.Items.AddRange(new object[] {
            "김마가",
            "김사가",
            "김바가",
            "김유가"});
            this.combo_trainer.Location = new System.Drawing.Point(100, 113);
            this.combo_trainer.Name = "combo_trainer";
            this.combo_trainer.Size = new System.Drawing.Size(92, 20);
            this.combo_trainer.TabIndex = 30;
            this.combo_trainer.SelectedIndexChanged += new System.EventHandler(this.combo_trainer_SelectedIndexChanged);
            // 
            // input_btn
            // 
            this.input_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.input_btn.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.input_btn.ForeColor = System.Drawing.Color.Black;
            this.input_btn.Location = new System.Drawing.Point(326, 106);
            this.input_btn.Name = "input_btn";
            this.input_btn.Size = new System.Drawing.Size(101, 26);
            this.input_btn.TabIndex = 29;
            this.input_btn.Text = "등록";
            this.input_btn.UseVisualStyleBackColor = true;
            this.input_btn.Click += new System.EventHandler(this.input_btn_Click);
            // 
            // textBox_end
            // 
            this.textBox_end.Location = new System.Drawing.Point(322, 47);
            this.textBox_end.Name = "textBox_end";
            this.textBox_end.Size = new System.Drawing.Size(93, 21);
            this.textBox_end.TabIndex = 27;
            // 
            // textBox_start
            // 
            this.textBox_start.Location = new System.Drawing.Point(322, 16);
            this.textBox_start.Name = "textBox_start";
            this.textBox_start.Size = new System.Drawing.Size(93, 21);
            this.textBox_start.TabIndex = 26;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(276, 52);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 25;
            this.label18.Text = "만료일";
            // 
            // button_okay1
            // 
            this.button_okay1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_okay1.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold);
            this.button_okay1.ForeColor = System.Drawing.Color.Black;
            this.button_okay1.Location = new System.Drawing.Point(326, 74);
            this.button_okay1.Name = "button_okay1";
            this.button_okay1.Size = new System.Drawing.Size(101, 26);
            this.button_okay1.TabIndex = 5;
            this.button_okay1.Text = "입력";
            this.button_okay1.UseVisualStyleBackColor = true;
            this.button_okay1.Click += new System.EventHandler(this.button_okay1_Click);
            this.button_okay1.MouseLeave += new System.EventHandler(this.button_okay1_MouseLeave);
            this.button_okay1.MouseHover += new System.EventHandler(this.button_okay1_MouseHover);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(275, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 24;
            this.label17.Text = "등록일";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "PT(횟수)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "수건 및 헬스복";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "등록 개월";
            // 
            // textBox_membership
            // 
            this.textBox_membership.Location = new System.Drawing.Point(100, 17);
            this.textBox_membership.Name = "textBox_membership";
            this.textBox_membership.Size = new System.Drawing.Size(92, 21);
            this.textBox_membership.TabIndex = 5;
            // 
            // textBox_lent
            // 
            this.textBox_lent.Location = new System.Drawing.Point(100, 47);
            this.textBox_lent.Name = "textBox_lent";
            this.textBox_lent.Size = new System.Drawing.Size(92, 21);
            this.textBox_lent.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_bmi);
            this.groupBox2.Controls.Add(this.textBox_weight);
            this.groupBox2.Controls.Add(this.textBox_height);
            this.groupBox2.Controls.Add(this.textBox_gender);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBox_age);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.textBox_addr);
            this.groupBox2.Controls.Add(this.textBox_phone);
            this.groupBox2.Controls.Add(this.textBox_name);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(28, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(314, 147);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // textBox_bmi
            // 
            this.textBox_bmi.Location = new System.Drawing.Point(250, 117);
            this.textBox_bmi.Name = "textBox_bmi";
            this.textBox_bmi.Size = new System.Drawing.Size(48, 21);
            this.textBox_bmi.TabIndex = 28;
            // 
            // textBox_weight
            // 
            this.textBox_weight.Location = new System.Drawing.Point(250, 81);
            this.textBox_weight.Name = "textBox_weight";
            this.textBox_weight.Size = new System.Drawing.Size(48, 21);
            this.textBox_weight.TabIndex = 27;
            // 
            // textBox_height
            // 
            this.textBox_height.Location = new System.Drawing.Point(250, 49);
            this.textBox_height.Name = "textBox_height";
            this.textBox_height.Size = new System.Drawing.Size(48, 21);
            this.textBox_height.TabIndex = 26;
            // 
            // textBox_gender
            // 
            this.textBox_gender.Location = new System.Drawing.Point(250, 16);
            this.textBox_gender.Name = "textBox_gender";
            this.textBox_gender.Size = new System.Drawing.Size(48, 21);
            this.textBox_gender.TabIndex = 25;
            // 
            // textBox_age
            // 
            this.textBox_age.Location = new System.Drawing.Point(80, 118);
            this.textBox_age.Name = "textBox_age";
            this.textBox_age.Size = new System.Drawing.Size(94, 21);
            this.textBox_age.TabIndex = 24;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(191, 121);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(27, 12);
            this.label16.TabIndex = 23;
            this.label16.Text = "BMI";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(191, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 22;
            this.label15.Text = "몸무게";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(191, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 12);
            this.label14.TabIndex = 21;
            this.label14.Text = "키";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(190, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 20;
            this.label12.Text = "성별";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 19;
            this.label10.Text = "나이";
            // 
            // textBox_addr
            // 
            this.textBox_addr.Location = new System.Drawing.Point(80, 82);
            this.textBox_addr.Name = "textBox_addr";
            this.textBox_addr.Size = new System.Drawing.Size(94, 21);
            this.textBox_addr.TabIndex = 4;
            // 
            // textBox_phone
            // 
            this.textBox_phone.Location = new System.Drawing.Point(80, 48);
            this.textBox_phone.Name = "textBox_phone";
            this.textBox_phone.Size = new System.Drawing.Size(94, 21);
            this.textBox_phone.TabIndex = 3;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(80, 15);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(94, 21);
            this.textBox_name.TabIndex = 2;
            // 
            // checkedListBox_membership
            // 
            this.checkedListBox_membership.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkedListBox_membership.FormattingEnabled = true;
            this.checkedListBox_membership.Items.AddRange(new object[] {
            "3개월 (7만원)",
            "6개월 (12만원)",
            "12개월 (20만원)"});
            this.checkedListBox_membership.Location = new System.Drawing.Point(28, 41);
            this.checkedListBox_membership.Name = "checkedListBox_membership";
            this.checkedListBox_membership.Size = new System.Drawing.Size(168, 76);
            this.checkedListBox_membership.TabIndex = 7;
            this.checkedListBox_membership.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox1_ItemCheck);
            // 
            // checkedListBox_pt
            // 
            this.checkedListBox_pt.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkedListBox_pt.FormattingEnabled = true;
            this.checkedListBox_pt.Items.AddRange(new object[] {
            "10회 (18만원)",
            "20회 (35만원)",
            "30회 (50만원)",
            "선택안함"});
            this.checkedListBox_pt.Location = new System.Drawing.Point(27, 25);
            this.checkedListBox_pt.Name = "checkedListBox_pt";
            this.checkedListBox_pt.Size = new System.Drawing.Size(168, 100);
            this.checkedListBox_pt.TabIndex = 8;
            this.checkedListBox_pt.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox3_ItemCheck);
            // 
            // checkedListBox_lent
            // 
            this.checkedListBox_lent.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkedListBox_lent.FormattingEnabled = true;
            this.checkedListBox_lent.Items.AddRange(new object[] {
            "3개월 (3만원)",
            "6개월 (6만원)",
            "12개월 (12만원)",
            "선택안함"});
            this.checkedListBox_lent.Location = new System.Drawing.Point(29, 29);
            this.checkedListBox_lent.Name = "checkedListBox_lent";
            this.checkedListBox_lent.Size = new System.Drawing.Size(168, 100);
            this.checkedListBox_lent.TabIndex = 9;
            this.checkedListBox_lent.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox2_ItemCheck);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkedListBox_membership);
            this.groupBox5.Location = new System.Drawing.Point(28, 165);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(224, 149);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "등록 개월(필수)";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkedListBox_lent);
            this.groupBox6.Location = new System.Drawing.Point(257, 165);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(221, 149);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "수건 + 헬스복 대여";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkedListBox_pt);
            this.groupBox7.Location = new System.Drawing.Point(484, 169);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(210, 145);
            this.groupBox7.TabIndex = 15;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "PT수강";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.SteelBlue;
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.pay_price);
            this.groupBox4.Controls.Add(this.pay_name);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.Location = new System.Drawing.Point(0, 350);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(816, 100);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(507, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 21);
            this.label13.TabIndex = 22;
            this.label13.Text = "입니다.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(242, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(162, 21);
            this.label11.TabIndex = 20;
            this.label11.Text = "님의  총 결제 금액은";
            // 
            // pay_price
            // 
            this.pay_price.BackColor = System.Drawing.Color.Transparent;
            this.pay_price.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pay_price.ForeColor = System.Drawing.Color.White;
            this.pay_price.Location = new System.Drawing.Point(413, 40);
            this.pay_price.Name = "pay_price";
            this.pay_price.Size = new System.Drawing.Size(88, 21);
            this.pay_price.TabIndex = 21;
            this.pay_price.Text = "---";
            // 
            // pay_name
            // 
            this.pay_name.BackColor = System.Drawing.Color.Transparent;
            this.pay_name.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pay_name.ForeColor = System.Drawing.Color.White;
            this.pay_name.Location = new System.Drawing.Point(171, 40);
            this.pay_name.Name = "pay_name";
            this.pay_name.Size = new System.Drawing.Size(71, 21);
            this.pay_name.TabIndex = 19;
            this.pay_name.Text = "---";
            // 
            // text_trainer
            // 
            this.text_trainer.Location = new System.Drawing.Point(198, 113);
            this.text_trainer.Name = "text_trainer";
            this.text_trainer.Size = new System.Drawing.Size(100, 21);
            this.text_trainer.TabIndex = 33;
            // 
            // add_change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(816, 450);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "add_change";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Menu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_membership;
        private System.Windows.Forms.TextBox textBox_lent;
        private System.Windows.Forms.TextBox textBox_addr;
        private System.Windows.Forms.TextBox textBox_phone;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.CheckedListBox checkedListBox_membership;
        private System.Windows.Forms.CheckedListBox checkedListBox_pt;
        private System.Windows.Forms.CheckedListBox checkedListBox_lent;
        private System.Windows.Forms.Button button_okay1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pay_price;
        private System.Windows.Forms.Label pay_name;
        private System.Windows.Forms.TextBox textBox_end;
        private System.Windows.Forms.TextBox textBox_start;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_bmi;
        private System.Windows.Forms.TextBox textBox_weight;
        private System.Windows.Forms.TextBox textBox_height;
        private System.Windows.Forms.TextBox textBox_gender;
        private System.Windows.Forms.TextBox textBox_age;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button input_btn;
        private System.Windows.Forms.ComboBox combo_trainer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_pt;
        private System.Windows.Forms.TextBox text_trainer;
    }
}