﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherClothes
{
    class Weather
    {
        private string date;
        private int rowtmp;
        private int hightmp;
        private string nalssi;

        public Weather(string date, int rowtmp, int hightmp, string nalssi)
        {
            this.date = date;
            this.rowtmp = rowtmp;
            this.hightmp = hightmp;
            this.nalssi = nalssi;
        }

        public string Date { get => date; set => date = value; }
        public int Rowtmp { get => rowtmp; set => rowtmp = value; }
        public int Hightmp { get => hightmp; set => hightmp = value; }
        public string Nalssi { get => nalssi; set => nalssi = value; }
    }
}
